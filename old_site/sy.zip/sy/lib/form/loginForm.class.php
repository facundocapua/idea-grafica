<?php

class loginForm extends sfForm
{
  public function configure()
  {
    //input's
    $this->setWidgets(array(
      'username'    => new sfWidgetFormInput(),
      'password'   => new sfWidgetFormInputPassword(),
    ));

    //labels
    $this->widgetSchema->setLabels(array(
  		'username' => 'Usuario',
  		'password' => 'Password',
	));

	//formato para el binding
	$this->widgetSchema->setNameFormat("login[%s]");

	//validadores
	$this->setValidators(array(
      'username' => new sfValidatorString(array('min_length' => 1)),
      'password' => new sfValidatorString(array('min_length' => 1))
    ));


  }
}