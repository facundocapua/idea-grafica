<?php

class basicFilterForm extends sfForm
{
  public function configure()
  {
    //input's
    $this->setWidgets(array(
      'text'    => new sfWidgetFormInput(),
      'status'   => new sfWidgetFormChoice(array(
    		'choices' => array('' => '', 0 => 'Inactivo', 1 => 'Activo')
    	)),
    ));

    //labels
    $this->widgetSchema->setLabels(array(
  		'text' => 'Texto',
  		'status' => 'Estado',
	));

	//formato para el binding
	$this->widgetSchema->setNameFormat("basicFilterForm[%s]");

	//validadores
	$this->setValidators(array(
      'text' => new sfValidatorString(array('min_length' => 1, 'max_length' => 255))
    ));


  }
}