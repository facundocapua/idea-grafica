<?php

/**
 * Privilege form base class.
 *
 * @method Privilege getObject() Returns the current form's model object
 *
 * @package    sy
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormGeneratedTemplate.php 29553 2010-05-20 14:33:00Z Kris.Wallsmith $
 */
abstract class BasePrivilegeForm extends BaseFormDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'id'         => new sfWidgetFormInputHidden(),
      'area'       => new sfWidgetFormInputText(),
      'category'   => new sfWidgetFormInputText(),
      'status'     => new sfWidgetFormInputText(),
      'order'      => new sfWidgetFormInputText(),
      'hardlink'   => new sfWidgetFormInputText(),
      'showInNav'  => new sfWidgetFormInputText(),
      'isChild'    => new sfWidgetFormInputText(),
      'credential' => new sfWidgetFormInputText(),
      'admin_list' => new sfWidgetFormDoctrineChoice(array('multiple' => true, 'model' => 'Admin')),
    ));

    $this->setValidators(array(
      'id'         => new sfValidatorChoice(array('choices' => array($this->getObject()->get('id')), 'empty_value' => $this->getObject()->get('id'), 'required' => false)),
      'area'       => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'category'   => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'status'     => new sfValidatorInteger(array('required' => false)),
      'order'      => new sfValidatorInteger(array('required' => false)),
      'hardlink'   => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'showInNav'  => new sfValidatorInteger(array('required' => false)),
      'isChild'    => new sfValidatorInteger(array('required' => false)),
      'credential' => new sfValidatorString(array('max_length' => 50, 'required' => false)),
      'admin_list' => new sfValidatorDoctrineChoice(array('multiple' => true, 'model' => 'Admin', 'required' => false)),
    ));

    $this->widgetSchema->setNameFormat('privilege[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Privilege';
  }

  public function updateDefaultsFromObject()
  {
    parent::updateDefaultsFromObject();

    if (isset($this->widgetSchema['admin_list']))
    {
      $this->setDefault('admin_list', $this->object->Admin->getPrimaryKeys());
    }

  }

  protected function doSave($con = null)
  {
    $this->saveAdminList($con);

    parent::doSave($con);
  }

  public function saveAdminList($con = null)
  {
    if (!$this->isValid())
    {
      throw $this->getErrorSchema();
    }

    if (!isset($this->widgetSchema['admin_list']))
    {
      // somebody has unset this widget
      return;
    }

    if (null === $con)
    {
      $con = $this->getConnection();
    }

    $existing = $this->object->Admin->getPrimaryKeys();
    $values = $this->getValue('admin_list');
    if (!is_array($values))
    {
      $values = array();
    }

    $unlink = array_diff($existing, $values);
    if (count($unlink))
    {
      $this->object->unlink('Admin', array_values($unlink));
    }

    $link = array_diff($values, $existing);
    if (count($link))
    {
      $this->object->link('Admin', array_values($link));
    }
  }

}
