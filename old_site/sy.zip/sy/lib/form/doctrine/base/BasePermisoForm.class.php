<?php

/**
 * Permiso form base class.
 *
 * @method Permiso getObject() Returns the current form's model object
 *
 * @package    sy
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormGeneratedTemplate.php 29553 2010-05-20 14:33:00Z Kris.Wallsmith $
 */
abstract class BasePermisoForm extends BaseFormDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'codigo'             => new sfWidgetFormInputHidden(),
      'area'               => new sfWidgetFormInputText(),
      'padre_texto'        => new sfWidgetFormInputText(),
      'activo'             => new sfWidgetFormInputText(),
      'orden'              => new sfWidgetFormInputText(),
      'hardlink'           => new sfWidgetFormInputText(),
      'mostrarennav'       => new sfWidgetFormInputText(),
      'eshijo'             => new sfWidgetFormInputText(),
      'credential'         => new sfWidgetFormInputText(),
      'administrador_list' => new sfWidgetFormDoctrineChoice(array('multiple' => true, 'model' => 'Administrador')),
    ));

    $this->setValidators(array(
      'codigo'             => new sfValidatorChoice(array('choices' => array($this->getObject()->get('codigo')), 'empty_value' => $this->getObject()->get('codigo'), 'required' => false)),
      'area'               => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'padre_texto'        => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'activo'             => new sfValidatorInteger(array('required' => false)),
      'orden'              => new sfValidatorInteger(array('required' => false)),
      'hardlink'           => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'mostrarennav'       => new sfValidatorInteger(array('required' => false)),
      'eshijo'             => new sfValidatorInteger(array('required' => false)),
      'credential'         => new sfValidatorString(array('max_length' => 50, 'required' => false)),
      'administrador_list' => new sfValidatorDoctrineChoice(array('multiple' => true, 'model' => 'Administrador', 'required' => false)),
    ));

    $this->widgetSchema->setNameFormat('permiso[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Permiso';
  }

  public function updateDefaultsFromObject()
  {
    parent::updateDefaultsFromObject();

    if (isset($this->widgetSchema['administrador_list']))
    {
      $this->setDefault('administrador_list', $this->object->Administrador->getPrimaryKeys());
    }

  }

  protected function doSave($con = null)
  {
    $this->saveAdministradorList($con);

    parent::doSave($con);
  }

  public function saveAdministradorList($con = null)
  {
    if (!$this->isValid())
    {
      throw $this->getErrorSchema();
    }

    if (!isset($this->widgetSchema['administrador_list']))
    {
      // somebody has unset this widget
      return;
    }

    if (null === $con)
    {
      $con = $this->getConnection();
    }

    $existing = $this->object->Administrador->getPrimaryKeys();
    $values = $this->getValue('administrador_list');
    if (!is_array($values))
    {
      $values = array();
    }

    $unlink = array_diff($existing, $values);
    if (count($unlink))
    {
      $this->object->unlink('Administrador', array_values($unlink));
    }

    $link = array_diff($values, $existing);
    if (count($link))
    {
      $this->object->link('Administrador', array_values($link));
    }
  }

}
