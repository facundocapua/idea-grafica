<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <?php include_http_metas() ?>
    <?php include_metas() ?>
    <?php include_title() ?>
    <link rel="shortcut icon" href="/favicon.ico" />
    <?php include_stylesheets() ?>
    <?php include_javascripts() ?>
  </head>
  <body>
    <!-- HEADER -->
    <table width="90%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
		<tr>
			<td align="left"><?php echo link_to('<h1>'.sfConfig::get('app_title').'</h1>', 'public/index'); ?></td>
		</tr>
	</table>
	<!-- HEADER END -->
    
    <!-- CONTENT -->
    <table width="90%" height="400" border="0" cellpadding="5" cellspacing="0" align="center" class="mainBody">
		<tr>
			<td width="140" valign="top">
				<?php if(has_slot('login')): ?>
					<?php include_slot('login'); ?>
				<?php else:?>
					<?php include_component('public', 'menu'); ?>
				<?php endif;?>
			</td>
			<td valign="top">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td width="3"><?php echo image_tag('tabtop_izq.gif', array('alt' => 'tab_img', 'width' => '3',  'height' => '21'))?></td>
						<td class="tabCenter" nowrap="nowrap">Index page</td>
						<td width="3"><?php echo image_tag('tabtop_der.gif', array('alt' => 'tab_img', 'width' => '3',  'height' => '21'))?></td>
						<td width="100%" valign="bottom"><?php echo image_tag('1x1.gif', array('alt' => 'tab_img', 'width' => '100%',  'height' => '1', 'style' => 'border-bottom:1px solid #999'))?></td>
					</tr>
				</table>
				<table width="100%" border="0" cellpadding="12" cellspacing="0" class="tabBody">
					<tr>
						<td style="padding-top:20px;" align="center">
							<?php echo $sf_content ?>
						</td>
					</tr>
				</table>
			</td>
			
			<td width="170" valign="top">
				<?php if(has_slot('right_sidebar')): ?>
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td width="3"><?php echo image_tag('tabtop_izq.gif', array('alt' => 'tab_img', 'width' => '3',  'height' => '21'))?></td>
						<td class="tabCenter" nowrap="nowrap">Options</td>
						<td width="3"><?php echo image_tag('tabtop_der.gif', array('alt' => 'tab_img', 'width' => '3',  'height' => '21'))?></td>
						<td width="100%" valign="bottom"><?php echo image_tag('1x1.gif', array('alt' => 'tab_img', 'width' => '100%',  'height' => '1', 'style' => 'border-bottom:1px solid #999'))?></td>
					</tr>
				</table>
				<?php include_slot('right_sidebar'); ?>
				<?php endif;?>
			</td>
			
		</tr>
	</table>
	<!-- CONTENT END -->
	
	<!-- FOOTER -->
	<table width="90%" border="0" cellpadding="0" cellspacing="0" align="center">
		<tr>
			<td height="15" align="right"><span class="texto_chico note">.copyright &copy;<?php echo date("Y");?></span></td>
		</tr>
	</table>
	<!-- FOOTER END -->	
  </body>
</html>
