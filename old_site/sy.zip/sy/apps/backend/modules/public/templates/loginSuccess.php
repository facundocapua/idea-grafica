<?php slot('login'); ?>
<form action="<?php echo url_for('public/login');?>" method="post">
	<?php echo $form->renderHiddenFields(false) ?>
	<table width="149" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<td width="3"><?php echo image_tag('tabtop_izq.gif', array('alt' => 'tab_img', 'width' => '3',  'height' => '21'))?></td>
			<td width="62" class="tabCenter"  nowrap="nowrap">Bienvenido</td>
			<td width="3"><?php echo image_tag('tabtop_der.gif', array('alt' => 'tab_img', 'width' => '3',  'height' => '21'))?></td>
			<td width="81" valign="bottom"><?php echo image_tag('1x1.gif', array('alt' => 'tab_img', 'width' => '100%',  'height' => '1', 'style' => 'border-bottom:1px solid #999'))?></td>
		</tr>
	</table>
	<table width="149" border="0" cellpadding="12" cellspacing="0" class="tabBody">
		<tr>
			<td width="123">
				<fieldset>
					<legend>Login</legend>
					<label>Usuario:
						<?php echo $form['username']->render(array( 'class' => 'input', 'style' => 'width:90px'));?>
					</label>
					<label>Password:
						<?php echo $form['password']->render(array( 'class' => 'input', 'style' => 'width:90px'));?>
					</label>
					
					<br />&nbsp;<br />
	
					<input type="submit" class="button" value="Ingresar" style="width:60px" />
				</fieldset>
			</td>
		</tr>
	</table>
</form>
<?php end_slot('login'); ?>