<table width="160" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="3"><?php echo image_tag('tabtop_izq.gif', array('alt' => 'tab_img', 'width' => '3',  'height' => '21'))?></td>
		<td width="62" class="tabCenter"  nowrap="nowrap">Bienvenido</td>
		<td width="3"><?php echo image_tag('tabtop_der.gif', array('alt' => 'tab_img', 'width' => '3',  'height' => '21'))?></td>
		<td width="81" valign="bottom"><?php echo image_tag('1x1.gif', array('alt' => 'tab_img', 'width' => '100%',  'height' => '1', 'style' => 'border-bottom:1px solid #999'))?></td>
	</tr>
</table>
<table width="160" border="0" cellpadding="12" cellspacing="0" class="tabBody">
  <tr>
    <td valign="top"><strong><?php echo $firstname.' '.$lastname; ?></strong>
      <br />
      <?php echo image_tag('1x1.gif', array('width' => '130', 'height' => '1', 'style' => 'background-color:#ccc;'))?><br />
      <a href="<?php echo url_for('public/logout');?>" title="Salir del sistema">Salir</a>
      </td>
  </tr>
</table>

<?php foreach($navigation as $category => $subNavigation):?>
<?php echo image_tag('1x1.gif', array('width' => '1', 'heigth' => '5'));?><br />
<table width="160" border="0" cellpadding="0" cellspacing="0" style="border-bottom:1px solid #85a3b5;">
	<tr>
		<td width="3"><?php echo image_tag('tabtop_izq.gif', array('alt' => 'tab_img', 'width' => '3',  'height' => '21'))?></td>
		<td width="144" class="tabCenter" nowrap="nowrap">
			<a href="javascript:;" class="menuCategory" rel="<?php echo stringsHelper::fileSystemName($category);?>">
				<?php echo image_tag('bt_menu_'.(empty($_COOKIE['admin_nav_'.stringsHelper::fileSystemName($category)]) ? 'up' : 'down').'.gif', array('id' => 'bt_'.stringsHelper::fileSystemName($category), 'width' => '11', 'height' => '11', 'border' => '0', 'align' => 'absmiddle'));?>
				&nbsp;&nbsp;<?php echo $category; ?>
			</a>
		</td>
		<td width="3"><?php echo image_tag('tabtop_der.gif', array('alt' => 'tab_img', 'width' => '3',  'height' => '21'))?></td>
	</tr>
	<tr>
		<td colspan="3">
			<div id="menu_<?php echo stringsHelper::fileSystemName($category);?>" style="display:<?php echo empty($_COOKIE['admin_nav_'.stringsHelper::fileSystemName($category)]) ? '' : 'none';?>">
				<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tabBody" style="border-bottom:0;">
					<tr>
						<td valign="top">
							<table width="100%" border="0" cellpadding="3" cellspacing="4" class="menuBody">
								<?php foreach($subNavigation as $subNavigationItem):?>
								<tr>
									<td class="<?php echo menuHelper::markNavigation($subNavigationItem['hardlink']); ?>">
										<?php echo $subNavigationItem["isChild"] ? '&nbsp;&nbsp;' : '';?>
										<?php echo image_tag('ico_padre'.($subNavigationItem["isChild"] ? '_hijos' : '').'.gif', array('width' => '13', 'height' => '14', 'border' => '0', 'align' => ($subNavigationItem['isChild'] ? 'abstop' : 'absmiddle') ));?>
										<a href="<?php echo url_for($subNavigationItem['hardlink']);?>" title="Ir al listado de registros de <?=htmlentities(strtolower($subNavigationItem['text']));?>"><?=ucfirst($subNavigationItem['text']);?></a>
								</tr>
								<?php endforeach;?>
							</table>
						</td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
</table>
<?php endforeach;?>