<?php

/**
 * public actions.
 *
 * @package    sy
 * @subpackage public
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class publicActions extends sfActions
{
	/**
	 * Executes index action
	 *
	 * @param sfRequest $request A request object
	 */
	public function executeIndex(sfWebRequest $request)
	{
		 
	}

	public function executeLogin(sfWebRequest $request){
		$this->form = new loginForm();
		 
		if ($request->isMethod('post')) {
			$data = $request->getParameter($this->form->getName());

			if($request->isMethod(sfRequest::POST)){

				//Bindeo los datos al formulario
				$this->form->bind($data);

				//Si es valido
				if ($this->form->isValid()) {
					$admin = Doctrine::getTable('Admin')->getAdmin($data['username'], $data['password']);

					if($admin !== FALSE){
						$this->getUser()->setAuthenticated(true);
						 
						$this->getUser()->setAttribute('id', $admin->getId());
						$this->getUser()->setAttribute('firstname', $admin->getFirstname());
						$this->getUser()->setAttribute('lastname', $admin->getLastname());
						 
						$this->getUser()->addCredential('user'); //Es usuario del sistema
						 
						foreach($admin->getPrivilege() as $privilege){
							$this->getUser()->addCredential($privilege->getCredential());
						}
						 
						$this->redirect('public/index');
					}
				}
			}
		}
	}

	public function executeLogout(sfWebRequest $request){
		$this->getUser()->clearCredentials();
		$this->getUser()->setAuthenticated(false);
		$this->getUser()->shutdown();
		$this->redirect('public/index');
	}
}
