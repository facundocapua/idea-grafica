<?php

class publicComponents extends sfComponents
{
 /**
  * Executes index action
  *
  * @param sfRequest $request A request object
  */
  public function executeMenu(sfWebRequest $request)
  {
  	$adminId = $this->getUser()->getAttribute('id',0);
  	
  	$admin = Doctrine::getTable('Admin')->find($adminId);
  	
  	$navigation = array();
  	
  	foreach($admin->getPrivilege() as $privilege){
  		
  		$navigationItem = array('text' => (string) $privilege->getArea(), 'hardlink' => (string) $privilege->getHardlink(), 'isChild' => (boolean) $privilege->getIsChild());
  		
  		if(isset($navigation[$privilege->getCategory()])){
  			$navigation[$privilege->getCategory()][] = $navigationItem; 
  		}else{
  			$navigation[$privilege->getCategory()] = array($navigationItem);
  		}
  	}
  	

  	$this->navigation = $navigation;
  	$this->firstname = $this->getUser()->getAttribute('name','');
  	$this->lastname = $this->getUser()->getAttribute('lastname','');
  }
}
