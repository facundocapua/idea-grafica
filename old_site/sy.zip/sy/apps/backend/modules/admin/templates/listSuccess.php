<table width="100%" border="0" cellpadding="0" cellspacing="1" class="tablaListado">
	<thead>
		<tr>
			<th>Nombre</th>
			<th>Apellido</th>
			<th width="100">Último ingreso</th>
			<th width="50">Estado</th>
		</tr>
	</thead>
	<?php foreach($admins as $admin):?>
	<tr class="filaListado">
		<td><a href="#" title="Editar este registro"> <?php echo $admin->getFirstname();?></a></td>
		<td><a href="#" title="Editar este registro"> <?php echo $admin->getLastname();?></a></td>
		<td><a href="#" title="Editar este registro"> <?php echo date('d/m/Y', $admin->getLastLogin());?>  </a></td>
		<td>
			<?php if($admin->getId()==1): ?>
			<?php echo image_tag('ico_'.($admin->getStatus()==1 ? 'on' : 'off').'.gif', array('width' => '13', 'height' => '13', 'border' => '0'));?>
			<?php else: ?>
			<a href="#" title="Cambiar estado de este registro"><?php echo image_tag('ico_'.($admin->getStatus()==1 ? 'on' : 'off').'.gif', array('width' => '13', 'height' => '13', 'border' => '0'));?></a>
			<?php endif; ?>	
		</td>
	</tr>
	<?php endforeach;?>
	<tr>
		<td colspan="4" class="celdaListadoFoot">
			<?php include_partial('shared/basicPager',array('pager' => $pager)); ?>
		</td>
	</tr>
</table>



<?php slot('right_sidebar');?>
<?php include_partial('shared/basicFilterForm',array('form' => $filterForm)); ?>
<?php end_slot('right_sidebar');?>