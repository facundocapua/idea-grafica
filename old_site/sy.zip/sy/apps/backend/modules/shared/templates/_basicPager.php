<?php if($pager->haveToPaginate()):?>

<?php $currentPage = $this->context->getRouting()->getCurrentInternalUri();?>

<center>Mostrando un total de <?php echo $pager->getNbResults();?> de registros</center>

<form action="<?php echo url_for($currentPage);?>" name="pagerForm" id="pagerForm" method="post">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<td width="33%" valign="middle">
				<?php if( $pager->getPage() > 1 ): ?>
				<a href="#" rel="<?php echo $pager->getPreviousPage();?>" class="pagerPreviousLink" title="Ir a la p&aacute;gina anterior de este listado">&laquo;Anterior</a>
				<?php endif; ?>
			</td>
			<td width="33%" align="center">
				<table width="150" cellpadding="0" cellspacing="0" border="0">
					<tr>
		  				<td width="65" align="right">Pag</td>
		  				<td width="20"><input type="text" id="page" name="page" value="<?php echo $pager->getPage(); ?>" title="Ingrese el n&uacute;mero de p&aacute;gina a la que desea ir y aprete la tecla Enter de su teclado." onKeyPress="return soloNum(event);" class="input" style="width:15px; height:13px"/></td>
		  				<td width="65" align="left"> de <?php echo $pager->getLastPage(); ?></td>
					</tr>
	  			</table>
		  	</td>
			<td width="33%" align="right" valign="middle">
				<?php if( $pager->getPage() < $pager->getLastPage() ): ?>
				<a href="<?php echo url_for($currentPage).'?page='.$pager->getNextPage();?>" title="Ir a la siguiente p&aacute;gina de este listado">Siguiente&raquo;</a> &nbsp;
				<? endif; ?>
			</td>
		</tr>
	</table>
</form>
<?php else:?>
<center><br />No se han encontrado registros</center><br />
<?php endif;?>

<script language="javascript" type="text/javascript">
$(document).ready(function(){
	$('.pagerPreviousLink').click(function(){
		$('#pagerForm #page').attr('value', $(this).attr('rel'));
		$('#pagerForm').submit();
	});
});


//function validarInputPaginado(){
//	if( parseInt(document.forms['paginadoListados'].pagina.value,10) <= 0){
//		document.forms['paginadoListados'].pagina.value = 1;
//		//return true;
//	}else if( parseInt(document.forms['paginadoListados'].pagina.value,10) <= <? #=$paginas;?> ){
//		//return true;
//	}else{
//		document.forms['paginadoListados'].pagina.value = <?#=$paginas;?>;
//		//return true;
//	}
//	return true;
//}
</script>