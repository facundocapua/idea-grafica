<form method="post" name="filtrar">
	<?php echo $form->renderHiddenFields(false) ?>
	<table width="100%" border="0" cellpadding="12" cellspacing="0" class="tabBody">
		<tr>
			<td>
				<fieldset>
					<legend>Filtrar por</legend>
					
					<?php echo $form['text']->renderLabel(); ?>:<br />
					<?php echo $form['text']->render(array( 'class' => 'input', 'style' => 'width:100px;font-weight:normal!important;', 'title' => 'Ingrese un texto o parte del mismo para realizar una b&uacute;squeda sobre los registros de esta secci&oacute;n'));?>
					<br />
					
					<?php echo $form['status']->renderLabel(); ?>:<br />
					<?php echo $form['status']->render(array( 'class' => 'select', 'style' => 'width:100px', 'title' => 'Seleccione de manera opcional el estado de los registros que desea filtrar en la b&uacute;squeda'));?>
					
					<br />

					<div style="padding-top: 5px">
						<input name="search"  type="submit" class="button" id="search" value="Filtrar" style="width:110px; height:25px;" title="Efectuar una busqueda en el listado" />
						<? if( !empty($isFiltered) ){?><br />
						<input name="showall"  type="button" class="button" id="showall" value="Sacar filtro" style="width:110px; height:25px;" onclick="location.href='<?=PAGINA_ACTUAL;?>_listado.php';" title="Voler a mostrar todos los registros" />
						<? }?>
					</div>
				</fieldset>
				<br />
				<input name="add" type="button" id="add" value="Agregar un nuevo Registro" style="width: 135px; height:35px; font-weight:bold;" class="button" title="Agregar un nuevo registro al listado de " /></td>
          </tr>
    </table>
</form>