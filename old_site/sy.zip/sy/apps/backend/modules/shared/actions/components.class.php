<?php

class sharedComponents extends sfComponents
{
 
}
