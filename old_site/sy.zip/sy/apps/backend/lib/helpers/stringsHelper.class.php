<?php
class stringsHelper{
	public static function fileSystemName($name, $character = '_'){
		$search = array(
			chr(192),chr(193),chr(194),chr(195),chr(224),chr(225),chr(226),chr(227), // a
			chr(201),chr(202),chr(233),chr(234), // e
			chr(205),chr(237), // i
			chr(211),chr(212),chr(213),chr(243),chr(244),chr(245), // o
			chr(218),chr(220),chr(250),chr(252), // u
			chr(199),chr(231), // c
			chr(209),chr(241) // ñ
		);
		$replace = array(
			'a','a','a','a','a','a','a','a',
			'e','e','e','e',
			'i','i',
			'o','o','o','o','o','o',
			'u','u','u','u',
			'c','c',
			'n','n'
		);
		$aux = strtolower(str_replace($search, $replace, $name));
		$aux = str_replace(' ',$character,$aux);
		$aux = preg_replace('/[^a-z0-9]/',$character,$aux);
		return $aux;
	}
}