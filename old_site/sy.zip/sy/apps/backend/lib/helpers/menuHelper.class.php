<?php
class menuHelper{
	public static function markNavigation(){
		$qqss = isset( $_SERVER['QUERY_STRING'] ) ? '?'.$_SERVER['QUERY_STRING'] : '';
		$numargs = func_num_args();
		$match = false;
		for($i = 0; $i < $numargs; $i++){
			$value = func_get_arg($i);
			if( strpos( strtolower(basename($_SERVER['SCRIPT_FILENAME']).$qqss) , strtolower($value) ) === false ){
				$match = false;
				break;
			}else{
				$match = true;
			}
		}
		if($match){
			return 'menuOff';
		}else{
			return 'menuOff';
		}
	}
}