function toggleNav(){
	var obj = $(this).attr('rel');
	
	$('#menu_'+obj).slideToggle('fast',function(){
		
		var currentSrc = $('#bt_'+obj).attr('src');
		
		if($('#menu_'+obj).css('display')=='none'){
			$('#bt_'+obj).attr('src', currentSrc.replace('up','down'));
			ocultar = 1;
		}else{
			$('#bt_'+obj).attr('src', currentSrc.replace('down','up'));
			ocultar = 0;
		}
		
		//Guardo la cookie
		$.ajax({
		   type: 'POST',
		   url: '/public/saveCookie',
		   data: 'nombre=admin_nav_'+obj+'&valor='+ocultar
		  });
	});
}

$(document).ready(function(){
	$('.menuCategory').click(toggleNav);
});