breadcrumb();
document.write('<META HTTP-EQUIV="Expires" CONTENT="1">');
document.write('<meta http-equiv="pragma" content="no-cache">');
function breadcrumb(){
	url = location.href.toString();
	partes = url.split('/')
	breadcrumb = partes[(partes.length-1)]
	breadcrumb = breadcrumb.split('.php');
	breadcrumb = breadcrumb[0];	
	breadcrumb = breadcrumb.replace(/[_|\?]/gi," > ")
	breadcrumb = "Backend > " + capitalize(breadcrumb);
	window.status = breadcrumb;	
	document.title = breadcrumb;
	document.write('<title>'+breadcrumb+'</title>');
}
function mostrarOcultar(obj, pagina){
	$('#'+obj).slideToggle('fast',function(){
		
		if(document.getElementById(obj).style.display=='none'){
			$('#bt_'+obj).attr('src','images/bt_menu_down.gif');
			ocultar = 1;
		}else{
			$('#bt_'+obj).attr('src','images/bt_menu_up.gif');
			ocultar = 0;
		}
		
		//Guardo la cookie
		$.ajax({
		   type: 'POST',
		   url: 'ajax_save_cookie.php',
		   data: 'nombre='+pagina+'_'+obj+'&valor='+ocultar
		  });
	});
}
function capitalize(str){
   words = str.split(" "); 
   for (i=0 ; i < words.length ; i++){
      testwd = words[i];
      firLet = testwd.substr(0,1); //lop off first letter
	  testwd.substr(0,1); //lop off first letter
      rest = testwd.substr(1, testwd.length -1)
      words[i] = firLet.toUpperCase() + rest   
   }         
   return words.join(" ");
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function redondea(sVal, nDec){
	var n = parseFloat(sVal);
	var s = "0.00";
	if (!isNaN(n)){
		n = Math.round(n * Math.pow(10, nDec)) / Math.pow(10, nDec);
		s = String(n);
		s += (s.indexOf(".") == -1? ".": "") + String(Math.pow(10, nDec)).substr(1);
		s = s.substr(0, s.indexOf(".") + nDec + 1);
	}
	return s;
}
function popup(url,ancho,alto,id,extras){
	if(navigator.userAgent.indexOf("Mac")>0){ancho=parseInt(ancho)+15;alto=parseInt(alto)+15;}
	var left = (screen.availWidth-ancho)/2;
	var top = (screen.availHeight-alto)/2;
	if(extras!=""){extras=","+extras;};
	var ventana = window.open(url,id,'width='+ancho+',height='+alto+',left='+left+',top='+top+',screenX='+left+',screenY='+top+extras);
	var bloqueado = "AVISO:\n\nPara ver este contenido es necesario que desactive\nel Bloqueo de Ventanas para este Sitio."
	//var bloqueado = "WARNING:\n\nIn order to use this functionality, you need\nto deactivate Popup Blocking."
	if(ventana==null || typeof(ventana.document)=="undefined"){ alert(bloqueado) }else{ ventana.focus(); return ventana; };
}


/** FUNCIONES PARA EL CONTROL DUAL-PANE */ 
function asignarProducto(d){
	if(!document.getElementById){
		alert('Su Navegador no soporta esta funcion.');
		return;
	}
	var todos = d.productosTodos
	if(todos.selectedIndex==-1){
		alert("Seleccione el Producto que desea asignar."); return;
	}
	var asignarValue = todos.options[todos.selectedIndex].value
	var asignarText = todos.options[todos.selectedIndex].text
	todos.selectedIndex = -1
	var asignados = d["productosAsignados[]"]
	for(i=0; i<asignados.length; i++)
		if(asignados.options[i].value == asignarValue){
			alert("Ese producto ya est� asignado."); return;
		}
	var asignadoNuevo = document.createElement("option")
	asignadoNuevo.value = asignarValue
	asignadoNuevo.text = asignarText
	var idxDelNuevo = (document.all)? 0 : asignados.options[0] ;
	asignados.add(asignadoNuevo,idxDelNuevo)
}

function quitarProducto(d){
	if(!document.getElementById){
		alert('Su Navegador no soporta esta funcion.');
		return;
	}
	var asignados = d["productosAsignados[]"]
	if(asignados.selectedIndex==-1){
		alert("Seleccione el Producto que desea desasignar."); return;
	}
	asignados.remove(asignados.selectedIndex)
}

function moverAsignado(d, movimiento){
	if(!document.getElementById){
		alert('Su Navegador no soporta esta funcion.');
		return;
	}
	var asignados = d["productosAsignados[]"]
	if(asignados.selectedIndex==-1){
		alert("Seleccione el Producto que desea mover."); return;
	}
	idx_old = asignados.selectedIndex;
	if( idx_old + movimiento < 0 || idx_old + movimiento >= asignados.options.length) return;
	
	asignarValue = asignados[idx_old].value;
	asignarText = asignados[idx_old].text;
	asignados.remove(idx_old);

	asignadoNuevo = document.createElement("option")
	asignadoNuevo.value = asignarValue
	asignadoNuevo.text = asignarText	
	idx_new = (document.all)? idx_old + movimiento : asignados.options[idx_old + movimiento] ;
	asignados.add(asignadoNuevo,idx_new)

	asignadoNuevo.selected = true;

}

function confirmarAsignados(d){
	if(d["productosAsignados[]"]){
		var asignados = d["productosAsignados[]"]
		asignados.multiple = true
		for(i=0;i<asignados.length;i++) asignados.options[i].selected = true;
	}
	d.submit();
}



function all_chk2(fld, action, formname){
// Action: 0=Deseleccionar todos 1=Seleccionar todos -1=Invertir seleccion
	var f = document.forms[formname]
	for (var i=0; i<f.length; i++){
		var obj = f.elements[i]
		var name = obj.name
		if (name==fld){
			obj.checked = ((action==1)? true : ((action==0)? false : !obj.checked) );
		}
	}
}


function writeCookie(name, value, hours, path){
	var domain = document.domain;
	var expire = "";
	if(hours != null){
		expire = new Date((new Date()).getTime() + hours * 3600000);
		expire = "; expires=" + expire.toGMTString();
	}
	document.cookie = name + "=" + escape(value) + expire + "; path=" + path + "; domain=" + domain;
}
function readCookie(name){
	var cookieValue = "";
	var search = name + "=";
	if(document.cookie.length > 0){ 
		offset = document.cookie.indexOf(search);
		if (offset != -1){ 
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			cookieValue = unescape(document.cookie.substring(offset, end));
		}
	}

	return cookieValue;
}
var nav4SoloNum = window.Event ? true : false;
function soloNum( evento ){ 
	var f = document.formulario
	var key = nav4SoloNum ? evento.which : evento.keyCode;
	return (key <= 13 || key == 8 || (key >= 48 && key <= 57));
}


var nav4SoloNumDecimal = window.Event ? true : false;
function soloNumDecimal( evento ){ 
	var f = document.formulario
	var key = nav4SoloNumDecimal ? evento.which : evento.keyCode;
	return (key <= 13 || key == 8 || (key >= 48 && key <= 57) || key == 46 /*punto*/ );
}


function mostrar_msj_error(obj_id){
	$('#alertar_error_'+obj_id).show(); 
	/*$('#'+obj_id).css({'background-color':'#FFC'});*/
}
function ocultar_msj_error(obj_id){
	$('#alertar_error_'+obj_id).hide();
	/*$('#'+obj_id).css({'background-color':'#f3f3f3'});*/
}
function ocultar_msjs_error(){
	$('.label_mensajes_errores').hide(); 
	/*$('input').each(function(){
		$(this).css({'background-color':'#f3f3f3!important'});	   
	});
	*/

}

